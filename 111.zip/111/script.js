let timer;
let seconds = 0;
let minutes = 0;
let hours = 0;
let clickCount = 0;

const currentTimeDisplay = document.querySelector('.current-time');
const display = document.querySelector('.display');
const startButton = document.querySelector('.start');
const stopButton = document.querySelector('.stop');
const resetButton = document.querySelector('.reset');
const clickCountDisplay = document.querySelector('.click-count');

function startTimer() {
  timer = setInterval(updateDisplay, 1000);
}

function stopTimer() {
  clearInterval(timer);
}

function resetTimer() {
  clearInterval(timer);
  seconds = 0;
  minutes = 0;
  hours = 0;
  updateDisplay();
}

function updateDisplay() {
  seconds++;
  if (seconds === 60) {
    seconds = 0;
    minutes++;
    if (minutes === 60) {
      minutes = 0;
      hours++;
    }
  }

  const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  display.textContent = formattedTime;
}

function updateCurrentTime() {
  const now = new Date();
  const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
  currentTimeDisplay.textContent = `Current Time: ${currentTime}`;
}

function updateClickCount() {
  clickCount++;
  clickCountDisplay.textContent = `Clicks: ${clickCount}`;
}

startButton.addEventListener('click', () => {
  startTimer();
  updateClickCount();
});
stopButton.addEventListener('click', () => {
  stopTimer();
  updateClickCount();
});
resetButton.addEventListener('click', () => {
  resetTimer();
  updateClickCount();
});
updateCurrentTime();
